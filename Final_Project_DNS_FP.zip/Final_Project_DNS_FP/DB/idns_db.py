'''
TODO:
this db should save some data:
1. DNS server ip
2. Domain Name
3. tester name
4. computer name
5. time of sample
6. os when sample
7. DNS request
8. DNS response
9. Session's Name
'''
from abc import abstractmethod


class IDNS_DB:
    @abstractmethod
    def __init__(self):
        pass

    def a(self):
        pass


