class LabRunnerDNS:
    def __init__(self):
        pass

    def run_lab_test(self):
        pass